import React from 'react';

const Landing = () => {
  return (
    <div>
      Landing Coming Soon
      <br />
      <a href="/register">Register to Home</a>
    </div>
  );
};

export default Landing;
