import React from 'react';

const Home = () => {
  return (
    <div>
      <p>Congrats on reaching very Secure homePage</p>
    </div>
  );
};

export default Home;
