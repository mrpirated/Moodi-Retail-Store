Use command 'npm run dev' to run both backend and frontend concurrently.
